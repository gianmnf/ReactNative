import {StyleSheet} from 'react-native';
import Colors from '../../styles/colors';

const Styles = StyleSheet.create({
  containerPerfil: {
    backgroundColor: Colors.light,
    flex: 1,
  },
});

export default Styles;
