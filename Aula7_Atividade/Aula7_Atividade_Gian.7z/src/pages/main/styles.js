import { StyleSheet } from 'react-native';
import Metrics from '../../styles/metrics';
import Colors from '../../styles/colors';

const Styles = StyleSheet.create({ 
   
    

});

 

export default Styles;