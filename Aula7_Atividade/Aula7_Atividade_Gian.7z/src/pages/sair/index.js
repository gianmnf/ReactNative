import React from 'react';
import RNExitApp from 'react-native-exit-app';

function Sair() {
  RNExitApp.exitApp();

  return <></>;
}

export default Sair;
