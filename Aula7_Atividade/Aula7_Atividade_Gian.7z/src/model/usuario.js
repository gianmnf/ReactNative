export default class Usuario {
  idUsuario: int;
  nomeUsuario: String;
  ideUsuario: String;
  senhaUsuario: String;
  email: String;
  constructor() {
    this.idUsuario = 0;
    this.nomeUsuario = '';
    this.ideUsuario = '';
    this.senhaUsuario = '';
    this.email = '';
  }
}
